# metodes
"""Classe per crear un programa que te diu el nom"""
""" Concatenar nom i cognoms """
""" Saludar en català """
